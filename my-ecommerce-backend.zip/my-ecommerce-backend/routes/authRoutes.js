import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken'; // Token ke liye
const router = express.Router();
import User from '../models/User.js';

// 1. SIGNUP (User Register)
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const userExists = await User.findOne({ email });
        if (userExists) return res.status(400).json({ message: "User pehle se registered hai" });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new User({ name, email, password: hashedPassword });
        await newUser.save();
        
        res.status(201).json({ message: "User ban gaya!" });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// 2. LOGIN (With JWT Token)
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (user && (await bcrypt.compare(password, user.password))) {
            // Token banana: Ismein User ID save hogi
            const token = jwt.sign(
                { id: user._id, isAdmin: user.isAdmin }, 
                process.env.JWT_SECRET, 
                { expiresIn: '30d' } // 30 din tak login rahega
            );

            res.json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                token: token // Frontend ye token save karega
            });
        } else {
            res.status(401).json({ message: "Invalid email or password" });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

export default router;