import express from 'express';
const router = express.Router();
import Product from '../models/Product.js';
import { admin } from '../middleware/authMiddleware.js'; // Middleware import kiya

// Saare products dekhna (Ye har koi kar sakta hai)
router.get('/', async (req, res) => {
    const products = await Product.find({});
    res.json(products);
});

// Naya product add karna (Sirf Admin kar sakta hai - isliye 'admin' lagaya)
router.post('/add', admin, async (req, res) => {
    try {
        const newProduct = new Product(req.body);
        await newProduct.save();
        res.status(201).json({ message: "Product Added by Admin!" });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

export default router;