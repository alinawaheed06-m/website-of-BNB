const express = require("express");
const router = express.Router();
const Order = require("../models/Order"); // Ensure path to Order.js is correct

// API: http://localhost:5000/api/orders/create
router.post("/create", async (req, res) => {
  try {
    console.log("📦 Incoming Order Data:", req.body); // Check terminal to see if data arrives

    const newOrder = new Order(req.body);
    const savedOrder = await newOrder.save();
    
    res.status(201).json({ 
      message: "Order placed successfully!", 
      orderId: savedOrder._id 
    });
  } catch (error) {
    // We send back the actual error message to help you debug in the browser
    console.error("❌ Order save error:", error.message);
    res.status(500).json({ 
      message: "Order save karne mein masla hua.", 
      error: error.message 
    });
  }
});

module.exports = router;