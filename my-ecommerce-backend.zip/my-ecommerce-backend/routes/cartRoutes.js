import express from 'express';
import Cart from '../models/Cart.js';
const router = express.Router();

// GET cart (guest by default)
router.get('/', async (req, res) => {
  try {
    const userId = req.query.userId || "guest";
    const cart = await Cart.findOne({ userId });
    res.json(cart || { items: [] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ADD item
router.post('/add', async (req, res) => {
  try {
    const { userId = "guest", productId, title, price, img, quantity } = req.body;
    const incomingQty = Number(quantity) || 1;

    let cart = await Cart.findOne({ userId });

    if (!cart) {
      cart = new Cart({
        userId,
        items: [{ productId, title, price, img, quantity: incomingQty }]
      });
    } else {
      const itemIndex = cart.items.findIndex(i => i.productId === productId);
      if (itemIndex > -1) {
        cart.items[itemIndex].quantity += incomingQty;
      } else {
        cart.items.push({ productId, title, price, img, quantity: incomingQty });
      }
    }

    await cart.save();
    res.status(200).json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE full cart
router.post('/update', async (req, res) => {
  try {
    const { userId = "guest", items } = req.body;
    const formattedItems = items.map(item => ({
      productId: item.productId,
      title: item.title,
      price: item.price.toString().replace(/,/g, ''),
      img: item.img,
      quantity: Number(item.quantity)
    }));

    const cart = await Cart.findOneAndUpdate(
      { userId },
      { $set: { items: formattedItems } },
      { upsert: true, new: true }
    );

    res.status(200).json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE item
router.delete('/delete/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const userId = req.query.userId || "guest";

    const cart = await Cart.findOne({ userId });
    if (cart) {
      cart.items = cart.items.filter(item => item.productId !== productId);
      await cart.save();
      res.status(200).json({ message: "Item deleted", cart });
    } else {
      res.status(404).json({ message: "Cart not found" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
