import jwt from 'jsonwebtoken';

export const admin = (req, res, next) => {
    // Frontend se token header mein aata hai
    const token = req.headers.authorization;

    if (token && token.startsWith('Bearer')) {
        try {
            // "Bearer <token>" mein se sirf token nikalna
            const actualToken = token.split(' ')[1];
            
            // Token ko verify karna
            const decoded = jwt.verify(actualToken, process.env.JWT_SECRET);
            
            // Check karna ke kya user admin hai
            if (decoded.isAdmin) {
                next(); // Agar admin hai to aage jane do
            } else {
                res.status(401).json({ message: "Not authorized as an admin" });
            }
        } catch (error) {
            res.status(401).json({ message: "Token failed, not authorized" });
        }
    } else {
        res.status(401).json({ message: "No token, no authorization" });
    }
};