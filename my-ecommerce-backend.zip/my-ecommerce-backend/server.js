import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

const app = express();
app.use(express.json()); 
app.use(cors());

// ----------------------------
// MongoDB Connection
// ----------------------------
mongoose.connect('mongodb://127.0.0.1:27017/my_ecommerce')
  .then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.error("❌ DB Error:", err));

// ----------------------------
// Schemas & Models
// ----------------------------

// Product Schema
const productSchema = new mongoose.Schema({
  title: String,
  price: Number,
  category: String,
  img: String,
  description: String,
  stock: Number,
  rating: { type: String, default: "4.8" },
  reviews: { type: String, default: "0" }
}, { timestamps: true });

const Product = mongoose.model('Product', productSchema, 'products');

// Cart Schema
const cartSchema = new mongoose.Schema({
  userId: { type: String, default: "guest" },
  items: [{
    productId: String,
    title: String,
    price: Number,
    img: String,
    quantity: { type: Number, default: 1 }
  }]
}, { timestamps: true });

const Cart = mongoose.model('Cart', cartSchema, 'carts');

// Order Schema
const orderSchema = new mongoose.Schema({
  contact: String,
  firstName: String,
  lastName: String,
  address: String,
  city: String,
  postalCode: String,
  phone: String,
  items: Array, 
  totalAmount: Number,
  paymentMethod: { type: String, default: "COD" },
  status: { type: String, default: "Pending" },
  createdAt: { type: Date, default: Date.now }
});

const Order = mongoose.model('Order', orderSchema, 'orders');

// ----------------------------
// LOGIN ROUTE
// ----------------------------
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    if (email === "admin@body.com" && password === "123") {
      res.status(200).json({ 
        message: "Login Successful", 
        isAdmin: true,
        user: { email, role: "admin" } 
      });
    } else {
      res.status(401).json({ error: "Invalid credentials!" });
    }
  } catch (err) {
    res.status(500).json({ error: "Login failed" });
  }
});

// ----------------------------
// ORDER ROUTES
// ----------------------------

// Fetch All Orders (Admin)
app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Orders fetch failed" });
  }
});

// Create New Order (Checkout)
app.post('/api/orders/create', async (req, res) => {
  try {
    const newOrder = new Order(req.body); 
    await newOrder.save();
    res.status(201).json({ message: "Order placed successfully!", order: newOrder });
  } catch (err) {
    res.status(500).json({ error: "Order save failed", details: err.message });
  }
});

// Update Order Status (NEW - Needed for Admin Dashboard)
app.put('/api/orders/status/:id', async (req, res) => {
  try {
    const { status } = req.body;
    const updatedOrder = await Order.findByIdAndUpdate(
      req.params.id, 
      { status: status }, 
      { new: true }
    );
    res.json(updatedOrder);
  } catch (err) {
    res.status(500).json({ error: "Status update failed" });
  }
});

// Delete Order (NEW - Needed for Admin Dashboard)
app.delete('/api/orders/:id', async (req, res) => {
  try {
    await Order.findByIdAndDelete(req.params.id);
    res.json({ message: "Order deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "Order delete failed" });
  }
});

// ----------------------------
// CART ROUTES
// ----------------------------
app.get('/api/cart', async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: "guest" });
    res.json(cart || { items: [] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cart/add', async (req, res) => {
  try {
    const { productId, title, price, img, quantity } = req.body;
    let cart = await Cart.findOne({ userId: "guest" });
    if (!cart) {
      cart = new Cart({ userId: "guest", items: [{ productId, title, price, img, quantity }] });
    } else {
      const idx = cart.items.findIndex(i => i.productId === productId);
      if (idx > -1) { cart.items[idx].quantity += quantity; } 
      else { cart.items.push({ productId, title, price, img, quantity }); }
    }
    await cart.save();
    res.status(200).json(cart);
  } catch (err) {
    res.status(500).json({ error: "Cart save failed" });
  }
});

app.post('/api/cart/update', async (req, res) => {
  try {
    const { items } = req.body;
    const cart = await Cart.findOneAndUpdate(
      { userId: "guest" },
      { items: items },
      { upsert: true, new: true }
    );
    res.status(200).json(cart);
  } catch (err) {
    res.status(500).json({ error: "Update failed" });
  }
});

app.delete('/api/cart/delete/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const cart = await Cart.findOneAndUpdate(
      { userId: "guest" },
      { $pull: { items: { productId: productId } } },
      { new: true }
    );
    res.status(200).json(cart);
  } catch (err) {
    res.status(500).json({ error: "Delete failed" });
  }
});

// ----------------------------
// PRODUCT ROUTES & ADMIN CRUD
// ----------------------------
app.get('/api/products', async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: "Fetch failed" });
  }
});

app.post('/api/products/add', async (req, res) => {
  try {
    const newProduct = new Product(req.body);
    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(500).json({ error: "Add product failed" });
  }
});

app.delete('/api/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: "Product deleted" });
  } catch (err) {
    res.status(500).json({ error: "Delete product failed" });
  }
});

app.put('/api/products/:id', async (req, res) => {
  try {
    const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Update product failed" });
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));