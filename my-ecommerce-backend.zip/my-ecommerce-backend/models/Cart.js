import mongoose from 'mongoose';

const CartSchema = new mongoose.Schema({
  userId: { type: String, default: "guest" }, // Compass ke mutabiq
  items: [{
    productId: { type: String, required: true },
    title: { type: String, required: true },
    price: { type: String, required: true },
    img: { type: String, required: true },
    quantity: { type: Number, default: 1 }
  }]
}, { timestamps: true });

export default mongoose.model('Cart', CartSchema);