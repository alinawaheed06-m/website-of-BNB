import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
    title: { type: String, required: true }, // 'name' ki jagah 'title'
    price: { type: Number, required: true },
    description: { type: String },
    category: { type: String },
    img: { type: String },                   // 'image' ki jagah 'img'
    rating: { type: String, default: "4.8" }, // Naya field
    reviews: { type: String, default: "0" },  // Naya field
    stock: { type: Number, default: 10 },
    isBestSeller: { type: Boolean, default: false }
}, { timestamps: true });

const Product = mongoose.model('Product', productSchema);
export default Product;