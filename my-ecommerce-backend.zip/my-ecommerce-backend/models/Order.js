const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
  contact: String,
  firstName: { type: String, required: true },
  lastName: String,
  address: { type: String, required: true },
  city: String,
  postalCode: String,
  phone: { type: String, required: true },
  
  items: [
    {
      title: { type: String, required: true },
      price: { type: Number, required: true },
      quantity: { type: Number, required: true },
      image: { type: String }
    }
  ],
  
  totalAmount: { type: Number, required: true },
  paymentMethod: { type: String, default: "COD" },
  status: { type: String, default: "Pending" },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Order", orderSchema);